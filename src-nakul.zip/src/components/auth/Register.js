import { useState } from "react"
import { useNavigate } from "react-router-dom"


export default function Register(){
    const nav = useNavigate()
    const[email,setEmail]= useState("")
    const[pass,setPass]= useState("")
    const handleform =(data)=>{
        data.preventDefault()
        if(email =="govindmaurya8699@gmail.com" && pass=="gobind"){
            nav("/about")
            console.log(" registeration successful")
        }else{
            console.log("unsuccess")
        }

    }
    return(
        <>
            <div class="container p-4 pt-5 rounded">
                <div class="row pt-5">
                <div class="col-md-12 pt-5 col-lg-12 pb-4 text-center logincolor">
                    <div class="">
                    <h1 class="title-single text-white ">Sign up</h1>
                    </div>
                </div>

                 <div className="container p-3 mx-auto shadow mt-4  ">
                <form onSubmit={handleform}>
                    <div class="form-group col-md-12 py-3">
                        <label for="name" className="h5 ">Name</label>
                    <input type="text" class="form-control my-3" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your name" required onChange={(data)=>{setEmail(data.target.value)}}/>
                       </div>
                    <div class="form-group col-md-12">
                        <label for="exampleInputEmail1 " className="h5 ">Email address</label>
                    <input type="email" class="form-control mt-3" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your email address" required onChange={(data)=>{setEmail(data.target.value)}}/>
                    </div>
                    <div className="row">
                    <div class="form-group col-md-3">
                        <label for="name" className="h5 my-3">Contact</label>
                    <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your phone number" required onChange={(data)=>{setEmail(data.target.value)}}/>
                       </div>
                       <div class="form-group col-md-3">
                        <label for="name" className="h5 my-3 ">Zip code</label>
                    <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your zip code" required onChange={(data)=>{setEmail(data.target.value)}}/>
                       </div>
                    
                       <div class="form-group col-md-6">
                        <label for="name" className="h5 my-3 ">Address</label>
                    <input type="text" class="form-control " id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter your home address" required onChange={(data)=>{setEmail(data.target.value)}}/>
                       </div>
                       </div>
                    
                       
                        <div class="col-md form-group mt-3">
                        <label className="h5 me-3 ">Gender</label>
                      
                        <input type="radio" name="Gender" id=""/>
                        <span class="h6 me-3">Male</span>
                        <input type="radio" name="Gender" id=""/>
                        <span class="h6 me-3">Female</span>
                        <input type="radio" name="Gender" id=""/>
                        <span class="h6 ">Others</span>
                      </div>
                        
                 
                    <div class="form-group row col-md-12">
                        <label for="exampleInputPassword1"className="h5 my-3 ">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required onChange={(data)=>{setPass(data.target.value)}}/>
                    </div>
                    <div class="form-group row col-md-12">
                        <label for="exampleInputPassword1"className="h5 my-3"> Confirm Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Confirm Password" required onChange={(data)=>{setPass(data.target.value)}}/>
                    </div>
                    <div class="form-group form-check col-md-12 my-3 tcol-md-12">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1"/>
                        <label class="form-check-label" className="h6 " for="exampleCheck1">Agree to all terms and conditions</label>
                    </div>
                    <div className="mb-3">
                    <button type="submit" class="btn btn-success d-block mx-auto ">Submit</button>
                    </div>
                        </form>
                </div>
                </div>
            </div>
           
        </>
    )
}