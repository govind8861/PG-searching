export default function Booking(){
    return(
        <>
            <div class="container mt-5">
                <div class="row mt-5">
                <div class="col-md-12 mt-5 col-lg-12 ">
                    <div class="title-single-box bg-light py-3 mt-5">
                    <h1 class="title-single text-center pb-4">Bookings</h1>
                    </div>
                </div>
              
               
                </div>
            </div>
            <div className="col-md-12 container mt-5">
               
               <table className="table table-striped ">
                <thead className="table-dark">

                    <tr>
                        <th>id</th>
                        <th>City</th>
                        <th>Category name</th>
                        <th>Room</th>
                        <th>Booking Date</th>
                        <th>Response</th>
                        <th>Booking Status</th>
                        <th>Created at</th>

                    </tr>
                </thead>
                <tbody>

                    <tr>
                                        <td>1</td>
                                        <td>jalandhar</td>
                                        <td>House</td>
                                        <td>2 BHK</td>
                                        <td>02/02/2023</td>
                                        <td>Good</td>
                                        <td>Active</td>
                                        <td>02/02/2023</td>
                                    
                    </tr>
                    <tr>
                                        <td>1</td>
                                        <td>jalandhar</td>
                                        <td>House</td>
                                        <td>2 BHK</td>
                                        <td>02/02/2023</td>
                                        <td>Good</td>
                                        <td>Active</td>
                                        <td>02/02/2023</td>
                                    
                    </tr>
                    <tr>
                                        <td>1</td>
                                        <td>jalandhar</td>
                                        <td>House</td>
                                        <td>2 BHK</td>
                                        <td>02/02/2023</td>
                                        <td>Good</td>
                                        <td>Active</td>
                                        <td>02/02/2023</td>
                                    
                    </tr>
                        <tr>
                                            <td>1</td>
                                            <td>jalandhar</td>
                                            <td>House</td>
                                            <td>2 BHK</td>
                                            <td>02/02/2023</td>
                                            <td>Good</td>
                                            <td>Active</td>
                                            <td>02/02/2023</td>
                                        
                        </tr>
                </tbody>
                </table>
                </div>
          
       
        </>
    )
}