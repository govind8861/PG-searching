export default function AddCity(){
    return(
        <>
        <div class="container mt-5">
                <div class="row mt-5 logincolor">
                {/* <div class="row mt-5 bg-success"> */}
                <div class="col-md-12 col-lg-12 mt-5">
                    <div class="title-single-box mt-5">
                    <h1 class="title-single pb-3 text-center text-white">Add City & State</h1>
                    </div>
                </div>
                </div>
                <div className="row">
                <div className="col-md-12 my-4 shadow py-5 rounded">
                <form >
                    <div class="form-group">
                        <label className="py-3">City</label>
                        <input type="text" class="form-control mb-4 rounded-pill" id="addcategory"  placeholder="enter city name here" required />
                     </div>
                    <div class="form-group">
                        <label className="py-3">State</label>
                        <input type="text" class="form-control mb-4 rounded-pill" id="addcategory"  placeholder="enter city name here" required />
                     </div>
                    <button type="submit" class="btn btn-success mx-auto d-block">Submit</button>
                </form>
                
                </div>
                </div>
            </div>
        
        </>
    )
}