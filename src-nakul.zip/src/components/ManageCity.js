import { Link } from "react-router-dom";

export default function ManageCity(){
    const data=[
        {
            city:'jalandhar',state:'punjab'
        },
        {
            city:'gorakhpur',state:'up'
        },
        {
            city:'jalandhar',state:'punjab'
        },
        {
            city:'jalandhar',state:'punjab'
        },
        {
            city:'jalandhar',state:'punjab'
        },
    ]
    return(
        <>
            <div class="container mt-5">
                <div class="row mt-5 bg-light">
                <div class="col-md-12 mt-5 col-lg-12">
                    <div class="mt-5">
                    <h1 class="pb-4 p-1 text-center">Manage City</h1>
                    </div>
                </div>
              
                <div className="col-md-12">
               
               <table className="table table-striped">
                <thead className="table-dark">
                 <tr>
                    
                    <th>id</th>
                    <th>City name</th>
                    <th>State</th>
                    <th>Action </th>
                </tr>
                </thead>
                <tbody>
                    {data.map((element,index)=>(
                             <tr >
                    
                             <td>{index+1}</td>
                             <td>{element.city}</td>
                             <td>{element.state}</td>

                             <td>
                             <Link to='/updatecity'> <i class="fa fa-edit fa-2x "></i></Link>&nbsp;&nbsp;

                                                                                        
                                <i class="fa fa-trash-o fa-2x "></i>
                            </td>
                            
                         </tr>
                    ))
                    }
               
                </tbody>
                </table>
                </div>
                </div>
            </div>
     
        </>
    )
}