import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { ToastContainer,toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css';
import { Link } from "react-router-dom";



export default function Login(){
    const nav = useNavigate()
    const[email,setEmail]= useState("")
    const[pass,setPass]= useState("")
    const handleform =(data)=>{
        data.preventDefault()
        if(email =="govindmaurya8699@gmail.com" && pass=="gobind"){
            nav('/register')
                toast("Succsefully login")
            console.log("successful")
        }else{
            console.log("unsuccess")
            toast("error occured")
        }

    }
    return(
        <>
              <div class="container mt-5">
                <div class="row mt-5 logincolor">
                {/* <div class="row mt-5 bg-success"> */}
                <div class="col-md-12 col-lg-12 mt-5">
                    <div class="title-single-box mt-5">
                    <h1 class="title-single pb-3 text-center text-white">Sign in</h1>
                    </div>
                </div>
                </div>
                <div className="row">
                <div className="col-md-12 my-5 shadow py-5 rounded">
                <form onSubmit={handleform} >
                    <div class="form-group">
                        <label className="py-3">Email Address</label>
                        <input type="email" class="form-control mb-1 rounded-pill" id="addcategory"  placeholder="enter your email here" required onChange={(data)=>{setEmail(data.target.value)}} />
                     </div>
                    <div class="form-group">
                        <label className="py-3">Password</label>
                        <input type="password" class="form-control mb-4 rounded-pill" id="addcategory"  placeholder="enter your password here" required  onChange={(data)=>{setPass(data.target.value)}}/>
                     </div>
                     <div class="form-group row">
                      {/* <button type='button' className="btn btn-link text btn-dark" >Forgot Password</button> */}
                      <p className="d-flex align-item-end"><Link to='/addcity'>Forgot Password</Link></p>

                            </div>                   
                    
                    <button type="submit" class="btn btn-success mx-auto d-block">Submit</button>
                </form>
                
                </div>
                </div>
            </div>
        
            <ToastContainer/>
        </>
    )
}