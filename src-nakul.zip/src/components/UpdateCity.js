export default function UpdateCity(){
    return(
        <>
            <div class="container mt-5">
                <div class="row mt-5">
                <div class="col-md-12 col-lg-12 logincolor pb-4 mt-5">
                    <div class="title-single-box mt-5">
                    <h1 class="title-single text-center text-white">Update City</h1>
                    </div>
                    
                </div>
              
                <div className="col-md-12 shadow mt-4">
                <form >
                    <div class="form-group col-md-12">
                        <label for="addcategory">City</label>
                    <input type="text" class="form-control mb-4 mt-2" id="addcategory"  placeholder="enter city name here" required />
                     </div>
                    <div class="form-group col-md-12">
                        <label for="addcategory" >State</label>
                    <input type="text" class="form-control mb-4 mt-2" id="addcategory"  placeholder="enter city name here" required />
                     </div>
                     <div className="mb-4">
                    <button type="submit" class="btn btn-success">Update</button>
                    </div>
                        </form>
                </div>
                </div>
            </div>
         
        </>
    )
}