import { Link } from "react-router-dom"
export default function ManageRoom(){
    return(
        <>
        <div class="container mt-5">
    <div class="row mt-5">
      <div class="col-md-12 col-lg-12 mt-5">
        <div class="title-single-box mt-5">
          <h1 class="title-single text-center">Manage Room</h1>
        </div>
      </div>
            </div>
  </div>
<div className="row col-md-12 row ps-4 mt-4">
    <table className="table table-striped table-bordered border-dark">
        <thead className="table-dark">
            <tr>
            <th>id</th>
            <th>Category Name</th>
            <th>Room Address</th>
            <th>City</th>
            <th>Rent</th>
            <th>Accomodation</th>
            <th>Image</th>
            <th>Descripiton</th>
            <th>Status</th>
            <th>Created_at</th>
            <th>Action</th>
    
        </tr>
        </thead>
        <tbody>
        <tr>
            <th>1</th>
            <th>Ac Room</th>
            <th>WS-86,Basti Sheikh</th>
            <th>Jalandhar</th>
            <th>$20</th>
            <th>Accomodation</th>
            <th><img src="/assets/assets/img/plan2.jpg" className="img-fluid"></img></th>
            <th>providing best facility</th>
            <th>unbooked</th>
            <th>1/1/2023</th>
            <td>
                            <Link to="/updateroom">
                                <i className="fa fa-edit text-success fa-2x"></i>
                            </Link> &nbsp;
                                <i className="fa fa-trash text-danger fa-2x"></i>
                            
                        </td>

        </tr>
        </tbody>
        
    </table>
</div>


        </>
    )
}