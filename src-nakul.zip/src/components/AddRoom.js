import { useState } from "react"
import { useNavigate } from "react-router-dom"

export default function AddRoom(){
    const nav = useNavigate()
    const[email,setEmail]= useState("")
    const[pass,setPass]= useState("")
    const handleform =(data)=>{
        data.preventDefault()
        if(email =="govindmaurya8699@gmail.com" && pass=="gobind"){
            nav("/about")
            console.log(" registeration successful")
        }else{
            console.log("unsuccess")
        }

    }
 
    return(
        <>
        <div class="container mt-5 logincolor">
    <div class="row mt-5">
      <div class="col-md-12 col-lg-12 mt-5">
        <div class="title-single-box mt-5 ">
          <h1 class="title-single text-center pb-4 text-white"> Add Room</h1>
        </div>
      </div>
            </div>
  </div>
{/* <div className="row col-md-12 row ps-4 mt-4">
    <table className="table table-striped table-bordered border-dark">
        <thead className="table-dark">
            <tr>
            <th>id</th>
            <th>Category Name</th>
            <th>Room Address</th>
            <th>City</th>
            <th>Rent</th>
            <th>Accomodation</th>
            <th>Image</th>
            <th>Descripiton</th>
            <th>Status</th>
            <th>Created_at</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th>1</th>
            <th>Ac Room</th>
            <th>WS-86,Basti Sheikh</th>
            <th>Jalandhar</th>
            <th>$20</th>
            <th>Accomodation</th>
            <th><img src="/assets/assets/img/plan2.jpg" className="img-fluid"></img></th>
            <th>providing best facility</th>
            <th>unbooked</th>
            <th>1/1/2023</th>
        </tr>
        </tbody>
        
    </table>
</div> */}
     <div className="container p-4 mx-auto shadow my-4 ">
                <form onSubmit={handleform}>
                    <div class="form-group col-md-12">
                        <label for="name" className="h5 ">Category Name</label>
                    <input type="text" class="form-control my-3" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Category name" required onChange={(data)=>{setEmail(data.target.value)}}/>
                       </div>
                    <div class="form-group col-md-12">
                        <label for="exampleInputEmail1 " className="h5 ">Room address</label>
                    <input type="text" class="form-control mt-3" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Room address" required onChange={(data)=>{setEmail(data.target.value)}}/>
                    </div>
                    <div className="form-gropu row">

                    <div class="form-group col-md-4">
                        <label for="name" className="h5 my-3 ">City</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter City" required onChange={(data)=>{setEmail(data.target.value)}}/>
                       </div>
                       <div class="form-group col-md-3">
                        <label for="name" className="h5 my-3">Rent</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Rent of the room" required onChange={(data)=>{setEmail(data.target.value)}}/>
                       </div>
                    
                       <div class="form-group col-md">
                        <label for="name" className="h5 my-3">Accomodation</label>
                    <input type="text" class="form-control " id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Accomodation of the room" required onChange={(data)=>{setEmail(data.target.value)}}/>
                       </div>         
                 
                    <div class="form-group row col-md-12">
                    </div>
                        <label for="exampleInputPassword1"className="h5 my-3 ">Image</label>
                        <input type="file" class="form-control" id="exampleInputPassword1" placeholder="Password" required onChange={(data)=>{setPass(data.target.value)}}/>
                    </div>
                    <div class="form-group row col-md-12">
                        <label for="exampleInputPassword1"className="h5 my-3 "> Description</label>
                        <textarea type="" class="form-control" id="exampleInputPassword1" placeholder="Enter the description" rows={10} required onChange={(data)=>{setPass(data.target.value)}}/>
                    </div>
                    <div className="py-3">

                    <button type="submit" class="btn btn-success d-block mx-auto ">Submit</button>
                    </div>
                        </form>
                </div>
            



        </>
    )
}