export default function UpdateCategory(){
    return(
        <>
            <div class="container mt-5">
                <div class="row mt-5">
                <div class="col-md-12 col-lg-12 mt-5 logincolor pb-4">
                    <div class="title-single-box mt-5">
                    <h1 class="title-single text-center text-white">Update Category</h1>
                    </div>
                </div>
              
                <div className="col-md-12 mt-5 shadow">
                <form >
                    <div class="form-group col-md-12 ">
                        <label for="addcategory"></label>
                    <input type="text" class="form-control mb-4" id="addcategory"  placeholder="enter category name here" required />
                     </div>
                     <div className="mb-4">
                    <button type="submit" class="btn btn-success p-2">Update</button>
                    </div>
                        </form>
                </div>
                </div>
            </div>
      
        </>
    )
}