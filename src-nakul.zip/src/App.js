import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import Master from './components/Master';
import About from './components/About';
import  Home from './components/Home';
import Contact from './components/Contact';
import AgentsGrid from './components/AgentsGrid';
import Login from './components/auth/Login';
import Property from './components/Property';
import Register from './components/auth/Register';
import BlogGrid from './components/BlogGrid';
import BlogSingle from './components/BlogSingle';
import PropertySingle from './components/PropertySingle';
import AgentSingle from './components/AgentSingle';
import AddCategory from './components/AddCategory';
import UpdateCategory from './components/UpdateCategory';
import ManageCategory from './components/ManageCategory';
import AddCity from './components/AddCity';
import UpdateCity from './components/UpdateCity';
import Feedback from './components/Feedback';
import ManageCity from './components/ManageCity';
import Booking from './components/Booking';
import ViewContact from './components/VIewContact';
import City from './components/City';
import Dashboard from './components/Dashboard';
import ViewFeedback from './components/ViewFeedback';
import AddRoom from './components/AddRoom';
import ManageRoom from './components/ManageRoom';
import Search from './components/Search';
import BookingRequest from './components/BookingRequest';
import UpdateRoom from './components/UpdateRoom';


function App() {
  return (
    <>
    
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Master/>}>
              <Route path='/' element={<Home />}></Route>
              <Route path='/Contact' element={<Contact />}></Route>
              <Route path='/bookingrequest' element={<BookingRequest />}></Route>
              <Route path='/viewContact' element={<ViewContact />}></Route>
              <Route path='/Home' element={<Home />}></Route>
              <Route path='/City' element={<City />}></Route>
              <Route path='/About' element={<About/>}></Route>
              <Route path='/AgentsGrid' element={<AgentsGrid/>}></Route>
              <Route path='/Login' element={<Login/>}></Route>
              <Route path='/Register' element={<Register/>}></Route>
              <Route path='/Property' element={<Property/>}></Route>
              <Route path='/BlogGrid' element={<BlogGrid/>}></Route>
              <Route path='/BlogSingle' element={<BlogSingle/>}></Route>
              <Route path='/PropertySingle' element={<PropertySingle/>}></Route>
              <Route path='/AgentSingle' element={<AgentSingle/>}></Route>
              <Route path='/Addcategory' element={<AddCategory/>}></Route>
              <Route path='/Updatecategory' element={<UpdateCategory/>}></Route>
              <Route path='/managecategory' element={<ManageCategory/>}></Route>
              <Route path='/addcity' element={<AddCity/>}></Route>
              <Route path='/addroom' element={<AddRoom/>}></Route>
              <Route path='/manageroom' element={<ManageRoom/>}></Route>
              <Route path='/updateroom' element={<UpdateRoom/>}></Route>
              <Route path='/managecity' element={<ManageCity/>}></Route>
              <Route path='/updatecity' element={<UpdateCity/>}></Route>
              <Route path='/feedback' element={<Feedback/>}></Route>
              <Route path='/booking' element={<Booking/>}></Route>
              <Route path='/dashboard' element={<Dashboard/>}></Route>
              <Route path='/search' element={<Search/>}></Route>
              <Route path='/viewfeedback' element={<ViewFeedback/>}></Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
