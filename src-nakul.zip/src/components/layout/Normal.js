import { useState } from "react"
import { useNavigate } from "react-router-dom"

export default function Login(){
    const nav = useNavigate()
    const [name,setName] = useState("")
    const [email,setEmail] = useState("")
    const [phonenumber,setPhoneNumber] = useState("")

    const handleEmail = (data) =>{
        // console.log(data.target.value)
        setEmail(data.target.value)
        // console.log(email)
    }

    const handleform = (e) => {
        e.preventDefault()
        // console.log(email)
        // console.log(password)
        if( name == "priyanka" && email == "priyanka28vr9@gmail.com" && phonenumber == "1234566789")
        {
            console.log("Login Successfully")
            nav("/about")
        }
        else{
            console.log("Invalid Email or password")
        }
    }

    return(
        <>
               <div class="contact_section_2 layout_padding">
               <div class="container-fluid">
                  <div class="row" bg-color="black">
                     <div class="col-md-6 padding_0">
                        <div class="map_main">
                           <div class="map-responsive">
                              <iframe
                                 src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0s1a7phLN0iaD6-UE7m4qP-z21pH0eSc&amp;q=Eiffel+Tower+Paris+France"
                                 width="600" height="500" frameborder="0" style={{' border': '0', width: '100%' }}
                                 allowfullscreen="">
                                    
                                 </iframe>
                           </div>
                        </div>
                     </div>
                     <div class="col-md-6">
                        <div class="mail_section_1">
                            <form onSubmit={handleform}>
                              <input type="text" class="mail_text" placeholder="Name" name="text" required onChange={(data)=>{setName(data.target.value)}} />
                           <input type="text" class="mail_text" placeholder="Email" name="text" required onChange={(data)=>{setEmail(data.target.value)}} />
                           <input type="text" class="mail_text" placeholder="Phone Number" name="text" required onChange={(data)=>{setPhoneNumber(data.target.value)}} />
                                                   
                           </form>
                           <button type="Submit">Submit</button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
        
        
        </>
    );
    }
