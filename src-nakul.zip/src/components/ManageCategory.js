import { Link } from "react-router-dom";

export default function ManageCategory(){
    return(
        <>
            <div class="container mt-5">
                <div class="row mt-5 bg-light">
                <div class="col-md-12 col-lg-12 mt-5">
                    <div class="title-single-box mt-5">
                    <h1 class="title-single pb-3 text-center">Manage Category</h1>
                    </div>
                </div>
                </div>
                <div className="row">
                <div className="col-md-12 my-5">
                
                <table className="table table-striped ">
                <thead className="table-dark">
                    <tr>
                        <th>id</th>
                        <th>Category name</th>
                        <th>Status</th>
                        <th>Action
                            
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>USER</td>
                        <td>Active</td>
                        <td>
                            <Link to="/updatecategory">
                                <i className="fa fa-edit text-success"></i>
                            </Link> &nbsp;
                                <i className="fa fa-trash text-danger"></i>
                            
                        </td>
                    </tr>

                </tbody>
                </table>
                </div>
                </div>
            </div>
        </>
    )
}