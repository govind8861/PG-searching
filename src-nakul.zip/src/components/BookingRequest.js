export default function BookingRequest(){
    return(
        <>
        <div class="container mt-5">
                <div class="col-md-12 row mt-5">
                <div class="col-md-12 col-lg-12 mt-5">
                    <div class="title-single-box mt-5 logincolor p-4 ">
                    <h1 class="text-white text-center">Booking</h1>
                    </div>
                </div>
              
                <div className="container shadow mt-4   ">
                    <div className="row col-md-12 mb-4 ">
                <form >
                    <div className="form-group my-3">
                        <label className="mb-2">Category</label>
                        <input type="text" className="form-control "></input>
                    </div>
                    <div className="form-group my-3">
                        <label className="mb-2">Room</label>
                        <input type="text" className="form-control"></input>
                    </div>
                    <div className="form-group my-3">
                        <label className="mb-2">City</label>
                        <input type="text" className="form-control"></input>
                    </div>
                    <div class="form-group">
                        <label for="addcategory" className="mb-2 me-2">Date</label>
                        <input type="date"></input>
                     </div>
                    <button type="submit" class="btn btn-success mt-3">Submit</button>
                </form>
                </div>
                </div>
                </div>
            </div>
        
        </>
    )
}