export default function UpdateRoom(){
    return(
        <>
        
        <div class="container mt-5">
                <div class="row mt-5">
                <div class="col-md-12 col-lg-12 logincolor pb-4 mt-5">
                    <div class="title-single-box mt-5">
                    <h1 class="title-single text-center text-white">Update Room</h1>
                    </div>
                    
                </div>
              
                <div className="col-md-12 shadow mt-4">
                <form >
                    <div class="form-group col-md-12">
                        <label for="addcategory">Category Name</label>
                    <input type="text" class="form-control mb-4 mt-2" id="addcategory"  placeholder="enter category name here" required />
                     </div>
                    <div class="form-group col-md-12">
                        <label for="addcategory" >Room Address</label>
                    <input type="text" class="form-control mb-4 mt-2" id="addcategory"  placeholder="enter Room Address here" required />
                     </div>
                    <div class="form-group col-md-12">
                        <label for="addcategory" >City</label>
                    <input type="text" class="form-control mb-4 mt-2" id="addcategory"  placeholder="enter city name here" required />
                     </div>
                    <div class="form-group col-md-12">
                        <label for="addcategory" >Accomodation</label>
                    <input type="text" class="form-control mb-4 mt-2" id="addcategory"  placeholder="enter accomodation name here" required />
                     </div>
                    <div class="form-group col-md-12">
                        <label for="addcategory" >Image</label>
                    <input type="file" class="form-control mb-4 mt-2" id="addcategory"  placeholder="enter Image name here" required />
                     </div>
                    <div class="form-group col-md-12">
                        <label for="addcategory" >Description</label>
                    <textarea type="text" class="form-control mb-4 mt-2" id="addcategory"  rows={5} placeholder="enter Description name here" required />
                     </div>
                    <div class="form-group col-md-12">
                        <label for="addcategory" >Status</label>
                    <input type="text" class="form-control mb-4 mt-2" id="addcategory"  placeholder="enter status name here" required />
                     </div>
                     <div className="mb-4">
                    <button type="submit" class="btn btn-success d-block mx-auto">Update</button>
                    </div>
                        </form>
                </div>
                </div>
            </div>
         
        </>
    )
}